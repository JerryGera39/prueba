<?php
class ConexionBD {
    private $servername = "localhost";
    private $username = "root";
    private $password = "";
    private $dbname = "manl";
    public $conn;
    

    public function __construct() {
        $this->conn = new mysqli($this->servername, $this->username, $this->password, $this->dbname);

        if ($this->conn->connect_error) {
            die("Conexión fallida: " . $this->conn->connect_error);
        }
        // echo "Conexión exitosa";
    }

    public function close() {
        $this->conn->close();
    }
}



?>