<?php
require_once '../Modelo/Usuario.php';
require_once 'UsuarioControlador.php';
require_once 'Sesion.php';

$session = new Sesion();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = filter_input(INPUT_POST, 'id', FILTER_SANITIZE_NUMBER_INT);
    $nombre = filter_input(INPUT_POST, 'nombre', FILTER_SANITIZE_STRING);
    $nombreUsuario = filter_input(INPUT_POST, 'usuario', FILTER_SANITIZE_STRING); 
    $rol = filter_input(INPUT_POST, 'rol', FILTER_SANITIZE_STRING);
    $token = filter_input(INPUT_POST, 'token', FILTER_SANITIZE_STRING);
    $tokenDecrypt = base64_decode($token);
    $tokenReal = $session->get("token");
    if ($nombre && $nombreUsuario && $rol && $id && $tokenDecrypt && ($tokenDecrypt == $tokenReal)) {
       
        
        $usuario = new Usuario();
        $usuario->setId($id);
        $usuario->setNombre($nombre);
        $usuario->setUsuario($nombreUsuario); 
        $usuario->setIdRol($rol);
        
        $usuarioControlador = new UsuarioControlador();
        $result = $usuarioControlador->editarUsuario($usuario);
        
        if ($result == "0") {
           header("Location: ../Vista/usuarios.php?msj=successEdit");
        } else {
            header("Location: ../Vista/usuarios.php?msj=".$result);
          
        }
    } else {
       echo "vacios";
    }
}



?>