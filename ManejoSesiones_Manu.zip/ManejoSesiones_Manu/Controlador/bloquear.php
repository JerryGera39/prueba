<?php
    require_once 'UsuarioControlador.php';

    if (isset($_POST['userId'])) {
        $user = $_POST['userId'];
    } else {
        exit;
    }
    
    $usuarioControlador = new UsuarioControlador();
    $usuario = $usuarioControlador->bloquear($user);
        
 

 ?>