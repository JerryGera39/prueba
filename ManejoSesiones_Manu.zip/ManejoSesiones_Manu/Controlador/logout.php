<?php

require_once 'Sesion.php';  

$sesion = new Sesion();  


$sesion->destroy();

header('Location: ../index.php');
exit;


?>