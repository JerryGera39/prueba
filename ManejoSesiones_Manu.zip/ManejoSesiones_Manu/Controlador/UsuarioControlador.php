<?php
require_once '../Modelo/Usuario.php';
require_once 'ConexionBD.php';
class UsuarioControlador{
    private $conexion;

    public function __construct() {
        
        $conexionBD = new ConexionBD();
        $this->conexion = $conexionBD->conn;
    }

    public function obtenerEstado($username){
        $sql = "SELECT estado FROM usuario WHERE usuario = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $usuario = $result->fetch_object('Usuario');
        $stmt->close();
        return $usuario->estado;
    }

    public function obtenerRoles() {
        $sql = "SELECT id, nombre FROM rol";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute();
        $result = $stmt->get_result();
        $roles = [];
        while ($rol = $result->fetch_object('Usuario')) {
            $roles[] = $rol;
        }
        $stmt->close();
        return $roles;
    }
    public function login($usuario){

        $sql = "SELECT estado,contrasenia,id_rol,nombre FROM usuario WHERE usuario = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->bind_param("s", $usuario->usuario);
        $stmt->execute();
        $result = $stmt->get_result();
        $usuario = $result->fetch_object('Usuario');
        $stmt->close();
        if($usuario){
            return  ["estado" => $usuario->estado , "pass" => $usuario->contrasenia,"rol" => $usuario->id_rol,"nombre" => $usuario->nombre];
        }else{ 
            return "1";
        }
    }

    public function bloquear($id){
        $sql = "UPDATE usuario SET estado = 0 WHERE id = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
        
    }
    public function desbloquear($id){
        $sql = "UPDATE usuario SET estado = 1 WHERE id = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
        
    }



    public  function obtenerTodosUsuarios() {
        $sql = "SELECT  id,nombre, usuario, estado, rol FROM usuarios";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute();
        $result = $stmt->get_result();
        $usuarios = [];
        while ($usuario = $result->fetch_object('Usuario')) {
            $usuarios[] = $usuario;
        }
        $stmt->close();
        return $usuarios;
    }

    public function crearUsuario($usuario) {
        $sql = "CALL crearUsuario (?, ?, ?, 1, @p_error)";
        $stmt = $this->conexion->prepare($sql);
    
        if ($stmt === false) {
            return "Error al preparar la declaración: " . $this->conexion->error;
        }
    
        $stmt->bind_param("sss", $usuario->nombre, $usuario->usuario, $usuario->password);
    
        if ($stmt->execute() === false) {
            $error = $stmt->error;
            $stmt->close();
            return "Error al ejecutar la declaración: " . $error;
        }
    
        $stmt->close();
    
        // Obtener el valor del parámetro de salida
        $result = $this->conexion->query("SELECT @p_error AS _error");
        $row = $result->fetch_assoc();
    
        return $row['_error'];
    }
    

    function buscarUsuario($username) {
        $sql = "SELECT  id,nombre, usuario, estado, rol FROM usuarios WHERE usuario LIKE ? OR nombre LIKE ?";
        $stmt = $this->conexion->prepare($sql);
        $searchUser = "%".$username."%";
        $stmt->bind_param("ss", $searchUser,$searchUser);
        $stmt->execute();
        $result = $stmt->get_result();
        $usuarios = [];
        while ($usuario = $result->fetch_object('Usuario')) {
            $usuarios[] = $usuario;
        }
        $stmt->close();

        if($usuarios){
            return $usuarios;
        }else{
            return null;
        }
        
    }

    public function editarUsuario($usuario) {
        $sql = "CALL actualizarUsuario (?, ?, ?, ?, @p_error)";
        $stmt = $this->conexion->prepare($sql);
    
        if ($stmt === false) {
            return "Error al preparar la declaración: " . $this->conexion->error;
        }
    
        $stmt->bind_param("issi",$usuario->id, $usuario->nombre, $usuario->usuario, $usuario->id_rol);
    
        if ($stmt->execute() === false) {
            $error = $stmt->error;
            $stmt->close();
            return "Error al ejecutar la declaración: " . $error;
        }
    
        $stmt->close();
    
        // Obtener el valor del parámetro de salida
        $result = $this->conexion->query("SELECT @p_error AS _error");
        $row = $result->fetch_assoc();
    
        return $row['_error'];

    }
    public function obtenerSeccionesBloqueadas($id_rol){
        $sql = "SELECT id_seccion  FROM rol_seccion WHERE id_rol = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->bind_param("i", $id_rol);
        $stmt->execute();
        $result = $stmt->get_result();
        $secciones = [];
        while ($rol = $result->fetch_assoc()) {
            $secciones[] = $rol;
        }
        $stmt->close();
        return $secciones;
    }

    public function obtenerAccionesBloqueadas($id_rol){
        $sql = "SELECT id_accion  FROM rol_accion WHERE id_rol = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->bind_param("i", $id_rol);
        $stmt->execute();
        $result = $stmt->get_result();
        $acciones = [];
        while ($rol = $result->fetch_assoc()) {
            $acciones[] = $rol;
        }
        $stmt->close();
        return $acciones;
    }

    public function eliminarUsuario($id) {
        $sql = "DELETE FROM usuario WHERE id = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->close();
    }

}
?>