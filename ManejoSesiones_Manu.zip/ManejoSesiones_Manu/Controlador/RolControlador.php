
<?php
// require_once '../Modelo/RolModel.php';
require_once 'ConexionBD.php';

class RolControlador {
    private $conexion;

    public function __construct() {
        $conexionBD = new ConexionBD();
        $this->conexion = $conexionBD->conn;

        if(isset ($_REQUEST["insertarNombreRol"])) {
            $this->insertarNombre();
        } elseif (isset ($_REQUEST["nombre"])) {
            $this->actualizarNombre($_REQUEST["id"], $_REQUEST["nombre"]);
        } elseif (isset ($_REQUEST["id"])){
            $this->borrarRol($_REQUEST["id"]);
        }
    }

    public function insertarNombre() {
        $nombre = $_REQUEST["insertarNombreRol"];
        $sql = "INSERT INTO rol (nombre) VALUES (?)";
        $stmt = $this->conexion->prepare($sql);
        $stmt->bind_param("s", $nombre);
        if ($stmt->execute()) {
            header ("Location: {$_SERVER["HTTP_REFERER"]}");
        } else {
            echo "Error al insertar el nombre: " . $stmt->error;
        }
        $stmt->close();
    }

    
    public function mostrarRoles() {
        $sql = "SELECT * FROM rol";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute();
        $result = $stmt->get_result();
        $datos = [];

        while ($fila = $result->fetch_assoc()) {
            $datos[] = $fila;
        }

        $stmt->close();
        return $datos;
    }

    // Método para actualizar un nombre
    public function actualizarNombre($id, $nombre) {
        $sql = "UPDATE rol SET nombre = ? WHERE id = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->bind_param("si", $nombre, $id);

        if ($stmt->execute()) {
            header ("Location: {$_SERVER["HTTP_REFERER"]}");
        } else {
            echo "Error al actualizar el nombre: " . $stmt->error;
        }

        $stmt->close();
    }

    public function borrarRol($id) {
        $sql = "CALL CambiarRolYEliminar(?)";
        $stmt = $this->conexion->prepare($sql);
    
        $stmt->bind_param("i", $id);
    
        if ($stmt->execute()) {
            header ("Location: {$_SERVER["HTTP_REFERER"]}");
        } else {
            echo "Ha ocurrido un error: " . $stmt->error;
        }
    
        // Cerrar la declaración
        $stmt->close();
    }
    


}

 $objeto = new RolControlador();
?>