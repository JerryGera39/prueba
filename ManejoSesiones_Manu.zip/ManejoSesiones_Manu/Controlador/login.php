<?php
require_once 'UsuarioControlador.php';
require_once '../Modelo/Usuario.php';
require_once 'Sesion.php';

$session = new Sesion();

 if(isset($_POST["username"]) && isset($_POST["contrasenia"])){
    $username = $_POST["username"];
    $pass = $_POST["contrasenia"];

        

    $usuario = new Usuario();

    
    $usuario->setUsuario($username);

    $usuarioControlador = new UsuarioControlador();
    $result = $usuarioControlador->login($usuario);
   if($result != "1"){
    if(password_verify($pass,$result["pass"])){
        if($result['estado'] == "1"){
        //Aqui guardare el token de la sesion y el usuario
            $session->set("usuario",$username);
            $session->set("nombre",$result["nombre"]);
            $session->set("token",md5(uniqid(mt_rand(), true)));
            $session->set("rol",$result["rol"]);
            
            if($result["rol"] == "1"){
                header("Location: ../Vista/menu.php");
            }else{
                header("Location: ../Vista/menuO.php");
            }
        }else{
            header("Location: ../index.php?msj=2");
        }
    }else{
        header("Location: ../index.php?msj=1");
    }
   }else{
    header("Location: ../index.php?msj=3");

   }
 }

?>