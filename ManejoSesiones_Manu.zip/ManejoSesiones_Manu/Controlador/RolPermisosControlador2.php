
<?php
if (isset($_REQUEST['rolesSeleccionados'])) {
  $rolesSeleccionados = $_REQUEST['rolesSeleccionados'];
  foreach ($rolesSeleccionados as $rolId) {
    // Procesar cada ID de rol seleccionado
    echo "Rol seleccionado: " . $rolId . "<br>";
  }
}
?>