<?php
if (isset($_POST['id']) && isset($_POST['checked'])) {
    $rolId = $_POST['id'];
    $isChecked = $_POST['checked'] == 'true';
    require "../Controlador/RolPermisosControlador.php";
    if ($_POST['cb'] == '1') {
        $x->mostrarPermisos($rolId);
    }
    elseif ($_POST['cb'] == '2') {
        $x->mostrarPermiso($rolId);
    }
}


?>
