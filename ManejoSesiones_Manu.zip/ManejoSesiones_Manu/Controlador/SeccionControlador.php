<?php
require_once 'ConexionBD.php';

class SeccionControlador
{
    private $conexion;

    public function __construct()
    {
        $conexionBD = new ConexionBD();
        $this->conexion = $conexionBD->conn;
        if (isset($_REQUEST['bloqueo'])) {
            foreach ($_REQUEST['bloquea'] as $key => $value) {
                $sql = "UPDATE seccion SET estado = 0 WHERE id = ?";
                $stmt = $this->conexion->prepare($sql);
                $stmt->bind_param("i", $value);
                $stmt->execute();
                $stmt->close();

            }
            header("Location:../Vista/permisos.php");
        }
    }

    function selectSecciones()
    {
        $sql = "SELECT * FROM seccion";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute();
        $result = $stmt->get_result();
        $datos = [];

        while ($fila = $result->fetch_assoc()) {
            $datos[] = $fila;
        }
        // foreach ($datos as $each){
        //     foreach ($each as $seccion){
        //         $secciones[] = $seccion;
        //     }

        // }
        // print_r($datos);
        $stmt->close();
        return $datos;
    }
    function selectAcciones()
    {
        $sql = "SELECT * FROM accion";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute();
        $result = $stmt->get_result();
        $datos = [];

        while ($fila = $result->fetch_assoc()) {
            $datos[] = $fila;
        }
        // foreach ($datos as $each){
        //     foreach ($each as $seccion){
        //         $secciones[] = $seccion;
        //     }

        // }
        // print_r($datos);
        $stmt->close();
        return $datos;
    }

    function inActivaSeccion($id) {
        $sql = "SELECT * FROM seccion";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute();
        $result = $stmt->get_result();
        $datos = [];

        while ($fila = $result->fetch_assoc()) {
            $datos[] = $fila;
        }
        // foreach ($datos as $each){
        //     foreach ($each as $seccion){
        //         $secciones[] = $seccion;
        //     }

        // }
        // print_r($datos);
        $stmt->close();
        return $datos;
    }
}

if (isset($_REQUEST['bloqueo'])) {
    $sc = new SeccionControlador();
}
