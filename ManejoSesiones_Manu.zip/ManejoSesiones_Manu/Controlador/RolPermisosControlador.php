<?php
require_once 'ConexionBD.php';
// require "../Controlador/RolControlador.php";

class RolSeccionControlador
{
    public $conexion;

    function __construct()
    {
        $conexionBD = new ConexionBD();
        $this->conexion = $conexionBD->conn;
        // $usuarios = $Rol->selectUsuarios();
        $this->getArgumentos();
    }

    public function getArgumentos()
    {
        if (isset($_REQUEST['rolesSeleccionados'])) {
            $rolesSeleccionados = $_REQUEST['rolesSeleccionados'];
    // si es que seleccionó roles, a cada uno le hará la insercion de las secciones y acciones
            foreach ($rolesSeleccionados as $idRol) {
                if (isset($_REQUEST['seccion'])) {
                    $seccion = $_REQUEST['seccion'];
                    // echo "Rol seleccionado: " . $idRol . "<br>";
                    $this->insertaRolSeccion($idRol, $seccion);
                }
                if (isset($_REQUEST['accion'])) {
                    $accion = $_REQUEST['accion'];
                    // echo "Rol seleccionado: " . $idRol . "<br>";
                    $this->insertaRolAccion($idRol, $accion);
                }
                header("Location: ../Vista/permisos.php");
            }
        }
    }

    function insertaRolSeccion($idRol, $idSeccion)
    {
        $sql = "DELETE FROM rol_seccion WHERE id_rol = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->bind_param("i", $idRol);
        $stmt->execute();
        $stmt->close();

        foreach ($idSeccion as $key => $value) {
            $sql = "INSERT INTO rol_seccion (id_rol, id_seccion) VALUES (?, ?)";
            $stmt = $this->conexion->prepare($sql);
            $stmt->bind_param("ii", $idRol, $value);
            $stmt->execute();
            $stmt->close();
        }
    }

    function insertaRolAccion($idRol, $idAccion)
    {
        $sql = "DELETE FROM rol_accion WHERE id_rol = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->bind_param("i", $idRol);
        $stmt->execute();
        $stmt->close();
        
        foreach ($idAccion as $key => $value) {
            $sql = "INSERT INTO rol_accion (id_rol, id_accion) VALUES (?, ?)";
            $stmt = $this->conexion->prepare($sql);
            print_r($value);
            $stmt->bind_param("ii", $idRol, $value);
            $stmt->execute();
            $stmt->close();
        }
    }
    
    
    function mostrarPermisos($idRol)
    {
        $sql = "SELECT id_seccion FROM rol_seccion WHERE id_rol = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->bind_param("i", $idRol);
        $stmt->execute();
        $result = $stmt->get_result();
        $datos = [];
    
        while ($fila = $result->fetch_assoc()) {
            $datos[] = $fila;
        }
        foreach ($datos as $each) {
            foreach ($each as $seccion) {
                $secciones[] = $seccion;
            }
        }
        echo json_encode($secciones);
        $stmt->close();
    }
    function mostrarPermiso($idRol){
        $sql = "SELECT id_accion FROM rol_accion WHERE id_rol = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->bind_param("i", $idRol);
        $stmt->execute();
        $result = $stmt->get_result();
        $datos = [];
    
        while ($fila = $result->fetch_assoc()) {
            $datos[] = $fila;
        }
        foreach ($datos as $each) {
            foreach ($each as $accion) {
                $acciones[] = $accion;
            }
        }
        echo json_encode($acciones);
        $stmt->close();
    }
}

$x = new RolSeccionControlador();
