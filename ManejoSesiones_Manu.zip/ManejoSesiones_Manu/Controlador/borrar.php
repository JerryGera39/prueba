<?php
require_once 'UsuarioControlador.php';
require_once '../Modelo/Usuario.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = filter_input(INPUT_POST, 'userId', FILTER_SANITIZE_NUMBER_INT);
    $usuarioControlador = new UsuarioControlador();
    $usuarioControlador->eliminarUsuario($id);
    header("Location: ../Vista/usuarios.php?msj=successDelete");
}

?>