<?php
require_once '../Modelo/Usuario.php';
require_once 'UsuarioControlador.php';
require_once 'Sesion.php';

$session = new Sesion();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = filter_input(INPUT_POST, 'nombre', FILTER_SANITIZE_STRING);
   // $nombreUsuario = filter_input(INPUT_POST, 'usuario', FILTER_SANITIZE_STRING); 
    $contrasena = filter_input(INPUT_POST, 'contrasenia', FILTER_SANITIZE_STRING);
    $rol = filter_input(INPUT_POST, 'rol', FILTER_SANITIZE_STRING);
    $token = filter_input(INPUT_POST, 'token', FILTER_SANITIZE_STRING);
    $tokenDecrypt = base64_decode($token);
    $tokenReal = $session->get("token");

    if ($nombre  && $contrasena && $rol && $tokenDecrypt && ($tokenDecrypt == $tokenReal)) {
        $hashedPassword = password_hash($contrasena, PASSWORD_DEFAULT);
        $usernameGenerado = generarUsername($nombre);
        $usuario = new Usuario();
        $usuario->setNombre($nombre);
        $usuario->setUsuario($usernameGenerado); 
        $usuario->setPassword($hashedPassword);
        $usuario->setIdRol($rol);
        
        $usuarioControlador = new UsuarioControlador();
        $result = $usuarioControlador->crearUsuario($usuario);
        
        if ($result == "0") {
           header("Location: ../Vista/usuarios.php?msj=success");
        } else {
            header("Location: ../Vista/usuarios.php?msj=".$result);
        }

    } else {
       echo "la solicitud no pertenece a la plataforma";
    }
}


    function generarUsername($nombre) {
        $nombre = preg_replace("/[^A-Za-z]/", "", $nombre);
        $randomString = substr(md5(time()), 0, 4);
        $username = $nombre . $randomString;
        if (strlen($username) < 5) {
            $username = str_pad($username, 5, "0"); 
        } elseif (strlen($username) > 15) {
            $username = substr($username, 0, 15); 
        }
        return $username;
    }
?>