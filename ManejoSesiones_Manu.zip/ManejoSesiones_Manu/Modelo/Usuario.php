<?php
    class Usuario{

        public $id; 
        public $nombre; 
        public $password; 
        public $id_rol; 
        public $usuario; 
        public $estado; 
        public $rol;

        public function getUsuario(){
            return $this->usuario;
        }

        public function setUsuario($usuario){
            $this->usuario = $usuario;
        }

        public function getEstado(){
            return $this->estado;
        }

        public function setEstado($estado){
            $this->estado = $estado;
        }

        public function getRol(){
            return $this->rol;
        }

        public function setRol($rol){
            $this->rol = $rol;
        }

        
        function __construct(){
        
        }


        public function getId(){
            return $this->id;
        }

        public function setId($id){
            $this->id = $id;
        }

        public function getNombre(){
            return $this->nombre;
        }

        public function setNombre($nombre){
            $this->nombre = $nombre;
        }

        public function getPassword(){
            return $this->password;
        }

        public function setPassword($password){
            $this->password = $password;
        }

        public function getIdRol(){
            return $this->id_rol;
        }

        public function setIdRol($id_rol){
            $this->id_rol = $id_rol;
        }
        

    }
?>  