<?php
    if(isset($_GET["msj"])){
        if($_GET["msj"] == "4"){
            $mensaje = "Debes de inciar sesion para entrar PENDEJO. <i class='bx bxs-ghost' style='font-size:50px;'></i>";
        }else if($_GET["msj"] != "3"){
            $mensaje = ($_GET["msj"] == "1") ?  "Contraseña incorrecta.Intente de nuevo<br><i class='bx bxs-error' style='font-size:50px;'></i>" : "Al parecer te encuentras Bloqueado de la plataforma. Para mayor informacion consulta con el adminitrador!.<br><i class='bx bx-block' style='font-size:80px;'></i>" ; 
        }else{
            $mensaje = "Usuario no encontrado.Intentelo de nuevo. <i class='bx bxs-ghost' style='font-size:50px;'></i>";
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    
</head>
<body>
    
    <div class="container">
        <div class="row justify-content-center align-items-center" style="height: 100vh;">
            <div class="col-md-6">
                <div class="login-container bg-white p-4 text-center">
                    <h3 class="m-5">Iniciar Sesión</h3>
                    <div class="mensaje error  m-5 <?=($mensaje) ? "": "d-none" ;  ?>">
                        <div class="alert alert-danger" role="alert">
                            <?= $mensaje;?>
                        </div> 
                    </div>
                    <form class="<?=(str_starts_with($mensaje, "A")) ? "d-none": "";?>" action="Controlador/login.php" method="POST">
                        <div class="form-group">
                            <label for="username">Usuario</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Contraseña</label>
                            <input type="password" class="form-control" id="password" name="contrasenia" required>
                        </div>
                        <button type="submit" class="btn btn-success btn-block mt-5">Entrar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>