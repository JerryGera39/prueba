
document.querySelectorAll(".bloquear-btn").forEach(button => {
    button.addEventListener("click", function() {
        const userId = button.getAttribute("data-userid");
        const swalWithBootstrapButtons = Swal.mixin({
            customClass: {
                confirmButton: "btn btn-success m-3",
                cancelButton: "btn btn-danger"
            },
            buttonsStyling: false
        });
        swalWithBootstrapButtons.fire({
            title: "¿Estas seguro?",
            text: "Bloquear a este usuario",
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: "Si, bloquear!",
            cancelButtonText: "No, cancelar!",
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                fetch('../Controlador/bloquear.php' , {
                    method : 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: 'userId=' + userId
                })
                .then(response => response.text())
                .then(data => { swalWithBootstrapButtons.fire({
                    title: "Bloqueado!",
                     text: "Has Bloqueado a un usuario de la plataforma.",
                      icon: "success" }); 
                      //document.querySelector(`#usuario-${userId}`).classList.add("table-danger");
                       setTimeout(() => {
                           location.reload();
                       }, 1000);
                   })
                .catch(error => {
                    console.error('Error:', error);
                });
               
            } else if (
                result.dismiss === Swal.DismissReason.cancel
            ) {
                swalWithBootstrapButtons.fire({
                    title: "Cancelado",
                    text: "No se ha hecho ninguna acción:)",
                    icon: "error"
                });
            }
        });
    });
});

document.querySelectorAll(".desbloquear-btn").forEach(button => {
    button.addEventListener("click", function() {
        const userId = button.getAttribute("data-userid");
        const swalWithBootstrapButtons = Swal.mixin({
            customClass: {
                confirmButton: "btn btn-success m-3",
                cancelButton: "btn btn-danger"
            },
            buttonsStyling: false
        });
        swalWithBootstrapButtons.fire({
            title: "¿Estas seguro?",
            text: "Desbloquear a este usuario",
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: "Si, Desbloquear!",
            cancelButtonText: "No, cancelar!",
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                fetch('../Controlador/desbloquear.php' , {
                    method : 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: 'userId=' + userId
                })
                .then(response => response.text())
                .then(data => { swalWithBootstrapButtons.fire({
                     title: "Desbloqueado!",
                      text: "Has Desbloqueado a un usuario de la plataforma.",
                       icon: "success" }); 
                       //document.querySelector(`#usuario-${userId}`).classList.add("table-danger");
                        setTimeout(() => {
                            location.reload();
                        }, 1000);
                    })
                .catch(error => {
                    console.error('Error:', error);
                });
           
            } else if (
                result.dismiss === Swal.DismissReason.cancel
            ) {
                swalWithBootstrapButtons.fire({
                    title: "Cancelado",
                    text: "No se ha hecho ninguna acción:)",
                    icon: "error"
                });
            }
        });
    });
});

document.querySelectorAll(".borrar-btn").forEach(button => {
    button.addEventListener("click", function() {
        const userId = button.getAttribute("data-userid");
        const swalWithBootstrapButtons = Swal.mixin({
            customClass: {
                confirmButton: "btn btn-success m-3",
                cancelButton: "btn btn-danger"
            },
            buttonsStyling: false
        });
        swalWithBootstrapButtons.fire({
            title: "¿Estas seguro?",
            text: "Borrar a este usuario implica PERMANENTEMENTE sacarlo de la plataforma no habra vuelta atras",
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: "Si, Borrar!",
            cancelButtonText: "No, Cancelar!",
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                fetch('../Controlador/borrar.php' , {
                    method : 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: 'userId=' + userId
                })
                .then(response => response.text())
                .then(data => { swalWithBootstrapButtons.fire({
                    title: "Eliminado!",
                     text: "Has Eliminado a un usuario de la plataforma.",
                      icon: "success" }); 
                     // document.querySelector(`#usuario-${userId}`).classList.add("table-danger");
                       setTimeout(() => {
                           location.reload();
                       }, 1000);
                   })
                .catch(error => {
                    console.error('Error:', error);
                });
               
            } else if (
                result.dismiss === Swal.DismissReason.cancel
            ) {
                swalWithBootstrapButtons.fire({
                    title: "Cancelado",
                    text: "No se ha hecho ninguna acción:)",
                    icon: "error"
                });
            }
        });
    });
});