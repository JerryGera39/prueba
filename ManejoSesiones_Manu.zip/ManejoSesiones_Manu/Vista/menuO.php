<?php
  require_once "../Controlador/Sesion.php";
 require_once "../Controlador/UsuarioControlador.php";

  $session = new Sesion();
  $usuarioControlador = new UsuarioControlador();
  $usuario = $session->get("nombre");
  $username = $session->get("usuario");
  $id_rol = $session->get("rol");
  
  $seccionesBloqueadas = $usuarioControlador->obtenerSeccionesBloqueadas($id_rol);

  $ids_secciones_bloqueadas = array_column($seccionesBloqueadas, 'id_seccion');
  
  $comprobar = $usuarioControlador->obtenerEstado($username);
  if($session->validarSesion()){
    header("Location: ../index.php?msj=4");
   }else if($comprobar == "0"){
     header("Location: paginaBloqueado.php");
     $session->destroy();
     exit;
   }


  $rol = $session->get("rol");
  if($rol == "1"){
    $rolText = "Administrador";
  }else if($rol == "3"){
    $rolText = "Operador";
  }else{
    $rolText = "Cliente";
  }
  
  $usuario = $session->get("nombre");
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="../Styles/menuStyles.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-light p-3 ">
    <a class="navbar-brand" href="#">Pagina Inicio</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse " id="navbarNavDropdown">

    </div>
    <div><?=$usuario?> - <?=$rolText?>     
   
    <a href="../Controlador/logout.php" class="btn btn-danger">Cerar Sesion</a>
  </div>
  </nav>
 
  <div id="content_menu" class="container-fluid">
  <?php
    if(!in_array(1,$ids_secciones_bloqueadas)){
      ?>
  
    <div class="card text-bg-primary mb-3" style="max-width: 18rem;">
      <div class="card-body">
        <h5 class="card-title">Sección 1</h5>
        <p class="card-text text-center"> <a class="enlace" href="../Vista/seccion1.php"><i class='bx bx-file' style="font-size:150px;"></i></a>
      </div>
    </div>
    
 <?php 
  } if(!in_array(2,$ids_secciones_bloqueadas)){
    ?>
    <div class="card text-bg-secondary mb-3" style="max-width: 18rem;">
      <div class="card-body">
        <h5 class="card-title">Sección 2</h5>
        <p class="card-text text-center"> <a class="enlace" href="../Vista/seccion2.php"><i class='bx bx-file' style="font-size:150px;"></i></a>
      </div>
    </div>
  <?php
  }
  ?>
  </div>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>

</html>