<?php
  require_once "../Controlador/Sesion.php";
 require_once "../Controlador/UsuarioControlador.php";

  $session = new Sesion();
  $usuarioControlador = new UsuarioControlador();
  $usuario = $session->get("nombre");
  $username = $session->get("usuario");
  if($session->get("rol") != "1"){
    $comprobar = $usuarioControlador->obtenerEstado($username);
  $accionesBloq = $usuarioControlador->obtenerAccionesBloqueadas($session->get("rol"));
  $ids_acciones_bloqueadas = array_column($accionesBloq, 'id_accion');
    
  }
  $comprobar = $usuarioControlador->obtenerEstado($username);
  if($session->validarSesion()){
    header("Location: ../index.php?msj=4");
   }else if($comprobar == "0"){
     header("Location: paginaBloqueado.php");
     $session->destroy();
     exit;
   }
  $rol = $session->get("rol");
  if($rol == "1"){
    $rolText = "Administrador";
  }else if($rol == "3"){
    $rolText = "Operador";
  }else{
    $rolText = "Cliente";
  }
  
  $usuario = $session->get("nombre");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seccion 1</title>
    <link rel="stylesheet" href="../Styles/menuStyles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

</head>
<body>  
<nav class="navbar navbar-expand-lg navbar-light bg-light p-3 ">
  <a class="navbar-brand" href="#">Pagina Inicio</a>
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
  <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse " id="navbarNavDropdown">
  <ul class="navbar-nav w-100">
  <li class="nav-item active">
        <a class="nav-link" href="<?=($rol == "1") ? "menu.php":"menuO.php";?>">Inicio</a>
      </li>
    </ul>
  </div>
  <div><?=$usuario?> - <?=$rolText?>     
   
    <a href="../Controlador/logout.php" class="btn btn-danger">Cerar Sesion</a>
  </div>
</nav>
<div id="content_menu" class="container-fluid">
<?php
    if(!in_array(21, $ids_acciones_bloqueadas)){
      
  ?>
    <div class="card text-bg-primary mb-3" style="max-width: 18rem;">
    <div class="card-body">
        <h5 class="card-title">Guardar</h5>
        <p class="card-text text-center"><i class='bx bxs-save' style="font-size:150px;"></i></p>
    </div>
    </div>
  <?php
  }
  ?>
  <?php
    if(!in_array(22, $ids_acciones_bloqueadas)){
      
  ?>
    <div class="card text-white bg-info mb-3" style="max-width: 18rem;">
    <div class="card-body">
        <h5 class="card-title">Mostrar/Buscar</h5>
        <p class="card-text text-center"><i class='bx bx-search' style="font-size:150px;"></i></p>
    </div>
    </div>
  <?php
  }
  ?>
  <?php
    if(!in_array(23, $ids_acciones_bloqueadas)){
      
  ?>
     <div class="card text-bg-danger mb-3" style="max-width: 18rem;">
    <div class="card-body">
        <h5 class="card-title">Eliminar</h5>
        <p class="card-text text-center"><i class='bx bxs-trash' style="font-size:150px;"></i></p>
    </div>
    </div>
  <?php
  }
  ?>
  <?php
    if(!in_array(24, $ids_acciones_bloqueadas)){
      
  ?>
    <div class="card text-bg-success mb-3" style="max-width: 18rem;">
    <div class="card-body">
        <h5 class="card-title">Modificar</h5>
        <p class="card-text text-center"><i class='bx bx-repost' style="font-size:150px;"></i></p>
    </div>
    </div>
  <?php
  }
  ?>
   
  
    
</div>

  
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>
</html>