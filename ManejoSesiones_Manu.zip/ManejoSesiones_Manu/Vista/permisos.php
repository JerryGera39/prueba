<?php
 require_once "../Controlador/Sesion.php";
 require_once "../Controlador/UsuarioControlador.php";
 
 $usuarioControlador = new UsuarioControlador();

 $session = new Sesion();

  
 $usuario = $session->get("nombre");
 $username = $session->get("usuario");
 $comprobar = $usuarioControlador->obtenerEstado($username);

 if($session->validarSesion()){
   header("Location: ../index.php?msj=4");
  }else if($comprobar == "0"){
    header("Location: paginaBloqueado.php");
    $session->destroy();
    exit;
  }
  
  
  
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Permisos</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" href="../Styles/usuariosStyle.css">
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <!-- Estilos personalizados -->
  <link rel="stylesheet" href="../Styles/usuariosStyle.css">
  <!-- Boxicons -->
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>

<body>


  <nav class="navbar navbar-expand-lg navbar-light bg-light p-3 bg-white mb-3">
    <a class="navbar-brand" href="#">Asignar Permisos</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse " id="navbarNavDropdown">
      <ul class="navbar-nav w-100">
        <li class="nav-item active">
          <a class="nav-link" href="menu.php">Inicio</a>
        </li>
      </ul>
    </div>
    <div><?=$usuario?> - Administrador     
    <a href="../Controlador/logout.php" class="btn btn-danger">Cerar Sesion</a>
  </div>
  </nav>
  <!-- Button trigger modal -->
  <button type="button" class="btn btn-primary m-3" data-bs-toggle="modal" data-bs-target="#exampleModal">
    <i class='bx bx-plus-circle'></i> Agregar Nuevo Rol
  </button>

  <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">

          <form action="../Controlador/RolControlador.php?=1" method="POST">
            <label for="nombreRol">Nombre del rol</label>
            <input name="insertarNombreRol" type="text" class="form-control" id="insertarNombreRol" placeholder="Nombre del rol" required>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Guardar Cambios</button>
          </form>

        </div>
      </div>
    </div>
  </div>
  <div class="permisos row">
    <?php
    
    require_once "layouts/tablaPermisos.php";
    require_once "layouts/permisosSecciones.php";
    ?>

  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <script>
    function cargaPermisos(checkbox) {
      let roleId = checkbox.value;
      let isChecked = checkbox.checked;
      let punteroCheckRoles;

      fetch('../Controlador/procesarCheck.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          body: `id=${roleId}&checked=${isChecked}&cb=1`
        })
        .then(response => response.json())
        .then(data => {
          data.forEach(element => {
            const cbSeccion = document.getElementById("seccion" + element)
            cbSeccion.checked = isChecked
          });
        }).catch(error => console.error('Error: ', error)
      );

      fetch('../Controlador/procesarCheck.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          body: `id=${roleId}&checked=${isChecked}&cb=2`
        })
        .then(response => response.json())
        .then(data => {
          data.forEach(element => {
            const cbAccion = document.getElementById("accion" + element)
            cbAccion.checked = isChecked
          });
        })
        .catch(error => console.error('Error: ', error));
    }
  </script>
</body>

</html>