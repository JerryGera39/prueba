        <div class="secciones">
          <?php
          require_once "../Controlador/SeccionControlador.php";
          $s = new SeccionControlador();
          $secciones = $s->selectSecciones();
          foreach ($secciones as $key => $seccion) {
          ?>
            <div class="card text-center mb-3" style="width: 18rem;">
              <div class="card-body">
                <h5 class="card-title">Sección <?= $seccion['nombre'] ?> <input type="checkbox" name="seccion[]" value="<?= $seccion['id'] ?>" id="seccion<?= $seccion['id'] ?>"></h5>
                <div class="card-text">
                  <?php
                  $acciones = $s->selectAcciones();
                  foreach ($acciones as $key => $accion) {
                    if ($seccion['id'] == $accion['id_seccion']) {
                  ?>
                      <div>
                        <label for=""><?= $accion['nombre'] ?></label>
                        <input id="accion<?= $accion['id'] ?>" type="checkbox" name="accion[]" value="<?= $accion['id'] ?>">
                      </div>
                  <?php
                    }
                  }
                  $paraBloqueoxSeccion[] = '<div>
                  <label for="bloque1">Bloquear ' . $seccion["nombre"] . ' para Todos</label>
                  <input type="checkbox" name="bloquea[]" value="' . $seccion["id"] . '">
                </div>
                <br><br><br><br><br>';
                  ?>
                </div>

              </div>
            </div>
          <?php
          }
          ?>

          <button class="btn btn-success" type="submit" form="form1">Asignar Permisos</button>
        </div>
        </td>
        <!-- </form> -->

        </form>
        <td>
          <div class="bloqueo">
            <form action="../Controlador/SeccionControlador.php" method="get">
              <div>
                <?php
                foreach ($paraBloqueoxSeccion as $key => $value) {
                  echo $value;
                }
                ?>
                <input type="hidden" name="bloqueo" value="1">

                <button class="btn btn-danger" type="submit"><i class='bx bx-block'></i>Bloquear</button>
              </div>

            </form>
          </div>
        </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        </tr>
        </table>