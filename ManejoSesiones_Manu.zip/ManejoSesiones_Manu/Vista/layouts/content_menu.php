<div id="content_menu" class="container-fluid">
  <div class="card text-white bg-primary mb-3" style="max-width: 18rem;">

    <div class="card-body">

      <h5 class="card-title">Usuarios</h5>
      <p class="card-text"> <a class="enlace" href="../Vista/usuarios.php"><i class='bx bxs-user' style="font-size:150px;"></i></a></p>


    </div>

  </div>
  <div class="card text-white bg-secondary mb-3" style="max-width: 18rem;">
    <div class="card-body">
      <h5 class="card-title">Permisos</h5>
      <p class="card-text text-center"> <a class="enlace" href="permisos.php"><i class='bx bx-key' style="font-size:150px;"></i></a>
      </p>
    </div>
  </div>

</div>