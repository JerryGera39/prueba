<?php
require_once "../Controlador/RolControlador.php";
if (isset($_REQUEST["id"])) {
  $rolControlador = new RolControlador();
  $nombre = $_REQUEST["nombre"];
  $id = $_REQUEST["id"];
  $rolControlador->actualizarNombre($id, $nombre);
  echo $nombre;
}
?>


<form class="" id="form1" action="../Controlador/RolPermisosControlador.php" method="get">
  <table class="table tabla text-center">
    <tr>
      <td>
        <table class="table tabla text-center">
          <thead>
            <tr>

              <th scope="col">Roles</th>
              <th scope="col">Selección</th>
              <th scope="col">Acciones</th>
              <th scope="col">Borrar Rol</th>

            </tr>
          </thead>
          <tbody>
            <!-- aqui un foreach generar los roles o si llegan a ingresar mas  -->

            <?php
            $obj = new RolControlador();
            $retorno = $obj->mostrarRoles();


            foreach ($retorno as $nombre) {
              if (strtolower($nombre["nombre"]) === "default") {
                continue;
              }
            ?>
              <tr>
                <th scope="row"><?= $nombre["nombre"] ?></th>

                <!--CHECKBOX-->
                <?php if (strtolower($nombre["nombre"]) !== "default") { ?>
                  <td><input type="checkbox" name="rolesSeleccionados[]" value="<?= $nombre["id"] ?>" onchange="cargaPermisos(this)"></td>
                <?php } ?>

                <!--BOTÓN DE EDICIÓN-->
                <?php if (strtolower($nombre["nombre"]) !== 'default') { ?>
                  <td><button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalEdit<?= $nombre["id"] ?>"><i class="bx bxs-pencil"></i></button></td>
                <?php } else { ?>
                  <td><span class="text-muted"></span></td>
                <?php } ?>

                <!--BOTÓN DE ELIMINACIÓN-->
                <?php if (strtolower($nombre["nombre"]) !== 'default') { ?>
                  <form action="../Controlador/RolControlador.php" method="POST">
                    <input type="hidden" name="id" value="<?= $nombre['id'] ?>">
                    <td><button type="submit" name="borrarRol" class="btn btn-danger btn-sm"><i class="bi bi-trash"></i></button></td>
                  </form>

                <?php } else { ?>
                  <span class="text-muted"></span>
                <?php } ?>
              </tr>

              <div class="modal fade" id="modalEdit<?= $nombre["id"] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h1 class="modal-title fs-5" id="exampleModalLabel">Editar Rol</h1>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                    </div>
                    <div class="modal-body">

                      <form action="../Controlador/RolControlador.php" method="POST">
                        <input type="hidden" name="id" value="<?= $nombre["id"] ?>">
                        <label for="actualizarNombreRol">Nuevo Nombre:</label>
                        <input type="text" id="actualizarNombreRol" name="nombre" value="<?= $nombre["nombre"] ?>" required>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                        <button type="submit" class="btn btn-primary">Guardar cambios</button>
                      </form>

                    </div>
                  </div>
                </div>
              </div>

            <?php } ?>
          </tbody>

        </table>

      </td>
      <td>