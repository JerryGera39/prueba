<nav class="navbar navbar-expand-lg navbar-light bg-light p-3 ">
  <a class="navbar-brand" href="#">Pagina Inicio</a>
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
  <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse " id="navbarNavDropdown">
    <ul class="navbar-nav w-100">
      <li class="nav-item active">
        <a class="nav-link" href="seccion1.php">Sección 1</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="seccion2.php">Sección 2</a>
      </li>
      
      
    </ul>
  </div>
  <div><?=$usuario?> - Administrador     
    <a href="../Controlador/logout.php" class="btn btn-danger">Cerar Sesion</a>
  </div>
</nav>
