<?php
  require_once "../Controlador/UsuarioControlador.php";
  require_once "../Controlador/Sesion.php";


  $session = new Sesion();
  $usuario = new UsuarioControlador();

  if(isset($_GET["nameBuscar"])){
    if($_GET["nameBuscar"] == ""){
    $usuarios = $usuario->obtenerTodosUsuarios();
    }else{
      $usuarios = $usuario->buscarUsuario($_GET["nameBuscar"]);
    }
  }else{
    $usuarios = $usuario->obtenerTodosUsuarios();
  }

  $username = $session->get("usuario");
  $comprobar = $usuario->obtenerEstado($username);

  if($session->validarSesion()){
    header("Location: ../index.php?msj=4");
  }else if($comprobar == "0"){
    header("Location: paginaBloqueado.php");
    $session->destroy();
    exit;

  }

  $roles = $usuario->obtenerRoles();
  if(isset($_GET["msj"])){
    $mensaje = $_GET["msj"];
  }
  $tokenEncrypt = base64_encode($session->get("token"));
  $nombreSession = $session->get("nombre");


  
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuarios</title>
    <link rel="stylesheet" href="../Styles/usuariosStyle.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</head>
<body>

<div class="container mb-5">
  <nav class=" bg-white navbar navbar-expand-lg navbar-light bg-light justify-content-between">
    <a class="navbar-brand" href="#">Usuarios</a>
    
    <ul class="navbar-nav w-100">
      <li class="nav-item active">
        <a class="nav-link" href="menu.php">Inicio</a>
      </li>
    </ul>
    
    <div><?=$nombreSession?>-Administrador
    <a href="../Controlador/logout.php" class="btn btn-danger">Cerar Sesion</a>
  </div>
  </nav>
</div>
<!-- Button trigger modal -->
<div class="cajita d-flex justify-content-between m-3  align-items-center">  
  <div>
  <button id="boton-modal" type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
  Guardar Nuevo Usuario
  </button>
  </div>
  <div class="buscar">
    <form action="" method="GET">
     <div class="d-flex justify-content-between align-items-center">
     <input class="form-control" type="text" name="nameBuscar" id="buscar" placeholder="Buscar Usuario">
     <button type="submit" class="btn btn-primary"><i class="bx bx-search"></i></button>
     </div>
    </form>
  </div>
</div>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Guardar Nuevo Usuario</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"></span>
        </button>
      </div>
      <div class="modal-body">
    <form method="POST" action="../Controlador/agregarUsuario.php">
    <div class="mb-3">
    <label for="nombre" class="form-label">Nombre</label>
    <input type="text" class="form-control" id="nombre" name="nombre" required pattern="[A-Za-z]{3,20}" title="El nombre debe contener solo letras y tener entre 3 y 20 caracteres.">
</div>
      <input type="hidden" id="token" name="token" value="<?=$tokenEncrypt;?>">
<div class="mb-3">
    <label for="contrasena" class="form-label">Contraseña</label>
    <input type="password" class="form-control" id="contrasena" name="contrasenia" required>
</div>
<div class="mb-3">
    <label for="tipoUsuario" class="form-label">Tipo de usuario</label>
    <select class="form-select" id="tipoUsuario" name="rol" required>
       <?php
        foreach($roles AS $rol){
          echo "<option value='".$rol->id."'>".$rol->nombre."</option>";
        }
       ?>
    </select>
</div>

       
    
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-primary">Guardar</button>
      </div>
      </form>
    </div>
  </div>
</div>
<div class="mensaje error  m-5 <?= ($mensaje == "1") ? "": "d-none" ;?>">
  <div class="alert alert-danger" role="alert">
   Error en el username utilizado ya esta en USO!. Por favor, inténtelo de nuevo.
  </div>
</div>
<table class="table text-center">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Nombre</th>
      <th scope="col">Username</th>
      <th scope="col">Rol</th>
      <th scope="col">Estado</th>
      <th scope="col">Acciones</th>

    </tr>
  </thead>
  <tbody>
    
    <?php
    $conteo = 1;
    if($usuarios != null){
      foreach($usuarios AS $usuario){
        
        ?>

        <tr id="usuario-<?=$usuario->id ?>" class="table-<?=($usuario->estado) == 1 ? 'success' : 'danger';?>">
        <th scope="row"><?=$conteo++?></th>
        <td><?= $usuario->nombre ?></td>
        <td><?= $usuario->usuario ?></td>
        <td><?= $usuario->rol ?></td>
        <td><?= ($usuario->estado) == 1 ? 'ACTIVO' : 'BLOQUEADO';?></td>

        <td>
        <?php
          if($usuario->estado == 1){
            echo "<button data-userid='".$usuario->id."'  class='btn btn-warning bloquear-btn'><i class='bx bx-block'></i></button>";
          }else{
            echo "<button data-userid='".$usuario->id."' class='btn btn-success desbloquear-btn'><i class='bx bx-check'></i></button>";
          }
        ?>
          
          <button data-userid="<?=$usuario->id?>" class="btn btn-danger borrar-btn "><i class='bx bxs-trash' ></i></button>
          <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#<?=$conteo;?>modalEditar"><i class='bx bxs-pencil' ></i></button>
        </td>
      </tr>
      

        <!-- Modal -->
        <div class="modal fade" id="<?=$conteo;?>modalEditar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Editar Usuario</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
              <form method="POST" action="../Controlador/actualizarUsuario.php">
                  <div class="mb-3">
                      <label for="nombre" class="form-label">Nombre</label>
                      <input type="text" class="form-control"  name="nombre" value="<?=$usuario->nombre;?>" required>
                  </div>
                    <input type="hidden" name="token" value="<?=$tokenEncrypt;?>">
                  <div class="mb-3">
                      <label for="usuario" class="form-label">Username</label>
                      <input type="text" class="form-control"  name="usuario" value="<?=$usuario->usuario;?>" required>
                  </div>
                    <!-- <div class="mb-3">
                      <label for="estado" class="form-label">Estado</label>
                      <input type="text" class="form-control"  name="estado" value="<?=($usuario->estado) == 1 ? 'ACTIVO' : 'BLOQUEADO' ;?>" readonly>
                    </div> -->
                    <input type="hidden"  name="id" value="<?=$usuario->id;?>" >

                    
                  <div class="mb-3">
                      <label for="tipoUsuario" class="form-label">Rol</label>
                      <select class="form-select" name="rol" required>
                      <?php
                        foreach($roles AS $rol){
                          echo "<option value='".$rol->id."'>".$rol->nombre."</option>";
                        }
                      ?>
                      </select>
                  </div>
                
              
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                  <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
      </form>
            </div>
          </div>
        </div>
      <?php
      }
    }else{
      echo "<tr><td colspan='6'>No hay usuarios registrados</td></tr>";
    }
    ?>

  </tbody>
</table>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="../javascript/usuariosJS.js"></script>
</body>
</html>