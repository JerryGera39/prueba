<?php
 require_once "../Controlador/Sesion.php";
 require_once "../Controlador/UsuarioControlador.php";
 
 $usuarioControlador = new UsuarioControlador();

 $session = new Sesion();

  
 $usuario = $session->get("nombre");
 $username = $session->get("usuario");
 $comprobar = $usuarioControlador->obtenerEstado($username);

 if($session->validarSesion()){
   header("Location: ../index.php?msj=4");
  }else if($comprobar == "0"){
    header("Location: paginaBloqueado.php");
    $session->destroy();
    exit;
  }
  
  
  
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../Styles/menuStyles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

</head>
<body>  

    <?php
   require_once "layouts/navbar.php";
    require_once "layouts/content_menu.php"; 
    ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</body>
</html>